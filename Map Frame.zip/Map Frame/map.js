class Example extends Phaser.Scene {
    constructor() {
        super();
    }
    preload() {
        this.load.image('bg', 'Assets/bg.png');
        this.load.image('seaBg', 'Assets/seabackground.png');
        // Load grid images
        const rows = ['A', 'B', 'C', 'D'];
        rows.forEach(row => {
            for (let col = 1; col <= 4; col++) {
                this.load.image(`${row}${col}`, `Assets/${row}${col}.png`);
            }
        });
    }
    // getQueryParam method removed as it's no longer needed
    create() {
        // Set the background color to black
        this.cameras.main.setBackgroundColor('#000000');

        // Add the background image as 'frame' on layer 2
        const frame = this.add.image(400, 300, 'bg');
        frame.setDepth(2);
        frame.setName('frame');

        // Create a mask based on the frame
        const mask = this.make.graphics();
        mask.fillRect(frame.x - frame.width / 2, frame.y - frame.height / 2, frame.width, frame.height);

        // Add the sea background image on layer 4 (deepest layer)
        const seaBackground = this.add.image(400, 300, 'seaBg');
        seaBackground.setDepth(0);
        seaBackground.setName('seaBackground');

        // Apply the mask to the sea background
        seaBackground.setMask(new Phaser.Display.Masks.GeometryMask(this, mask));

        // Create the 4x4 grid
        this.createGrid(mask);
    }
    createGrid(mask) {
        const gridContainer = this.add.container(400, 300);
        gridContainer.setDepth(1); // Set depth to 1 to ensure it's behind the Frame layer
        gridContainer.setName('Map body');
        const rows = ['A', 'B', 'C', 'D'];
        const tileSize = 100; // Adjust this value to change the size of each tile
        const gridSize = tileSize * 4;
        const startX = -gridSize / 2 + tileSize / 2;
        const startY = -gridSize / 2 + tileSize / 2;
        let originalImageWidth;
        rows.forEach((row, rowIndex) => {
            for (let col = 1; col <= 4; col++) {
                const x = startX + (col - 1) * tileSize;
                const y = startY + rowIndex * tileSize;
                const tile = this.add.image(x, y, `${row}${col}`);
                if (!originalImageWidth) {
                    originalImageWidth = tile.width;
                }
                tile.setDisplaySize(tileSize, tileSize);
                gridContainer.add(tile);
            }
        });
        // Calculate the maximum zoom based on original image size
        const maxZoom = originalImageWidth / tileSize;
        // Apply the mask to the grid container
        gridContainer.setMask(new Phaser.Display.Masks.GeometryMask(this, mask));
        // Get the frame dimensions
        const frame = this.children.getByName('frame');
        const frameWidth = frame.width;
        const frameHeight = frame.height;
        // Calculate the scale to fit the grid within the frame
        const scaleX = frameWidth / gridSize;
        const scaleY = frameHeight / gridSize;
        const scale = Math.min(scaleX, scaleY);
        // Apply the calculated scale
        gridContainer.setScale(scale);
        // Center the grid within the frame
        gridContainer.x = frame.x;
        gridContainer.y = frame.y;
        // Add zoom functionality
        this.input.on('wheel', (pointer, gameObjects, deltaX, deltaY, deltaZ) => {
            const zoomFactor = deltaY < 0 ? 1.1 : 0.9;
            const newScale = gridContainer.scale * zoomFactor;
            if (newScale >= scale && newScale <= maxZoom) { // Adjust zoom limits
                // Calculate the point to zoom towards (pointer position relative to container)
                const zoomPoint = {
                    x: (pointer.x - gridContainer.x) / gridContainer.scale,
                    y: (pointer.y - gridContainer.y) / gridContainer.scale
                };
                // Apply zoom
                gridContainer.scale *= zoomFactor;
                // Adjust position to zoom towards mouse pointer
                gridContainer.x = pointer.x - zoomPoint.x * gridContainer.scale;
                gridContainer.y = pointer.y - zoomPoint.y * gridContainer.scale;
            }
        });
        // Add drag functionality
        let isDragging = false;
        let dragStartX, dragStartY;
        this.input.on('pointerdown', (pointer) => {
            isDragging = true;
            dragStartX = pointer.x - gridContainer.x;
            dragStartY = pointer.y - gridContainer.y;
        });
        this.input.on('pointermove', (pointer) => {
            if (isDragging) {
                gridContainer.x = pointer.x - dragStartX;
                gridContainer.y = pointer.y - dragStartY;
            }
        });
        this.input.on('pointerup', () => {
            isDragging = false;
        });
    }
}

const config = {
    type: Phaser.AUTO,
    parent: 'renderDiv',
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
    },
    width: 800,
    height: 600,
    scene: Example
};

window.phaserGame = new Phaser.Game(config);